/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

import java.util.*;

class student{
    int marks1;
    int marks2;
    student(int marks1,int marks2){
        this.marks1=marks1;
        this.marks2=marks2;
    }
}

public class Main{
    public static void main(String[] args){
        List<student> list=new ArrayList<>();
        list.add(new student(13,24));
        list.add(new student(23,45));
        list.add(new student(13,244));
        list.add(new student(21,67));

        for(int i=1;i<list.size();i++){
            student key=list.get(i);
            int j=i-1;
            while(j>=0){
                student cur=list.get(j);
                if(cur.marks1>key.marks1 || 
                  (cur.marks1==key.marks1 && cur.marks2>key.marks2)){
                    list.set(j+1,cur);
                    j--;
                }else{
                    break;
                }
            }
            list.set(j+1,key);
        }

        for(student s:list){
            System.out.print(s.marks1+" ");
            System.out.println(s.marks2);
        }
    }
}
