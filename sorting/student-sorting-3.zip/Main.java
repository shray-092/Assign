import java.util.*;

class student1 {
    int marks1;
    int marks2;

    student1(int marks1, int marks2) {
        this.marks1 = marks1;
        this.marks2 = marks2;
    }


}

public class Main {
    public static void main(String[] args) {

        List<student1> list = new ArrayList<>();
        list.add(new student1(10, 20));
        list.add(new student1(90, 50));
        list.add(new student1(90, 40));
        list.add(new student1(70, 60));

        for (int i = 0; i < list.size() - 1; i++) {
            for (int j = 0; j < list.size() - i - 1; j++) {

                student1 a = list.get(j);
                student1 b = list.get(j + 1);

                if (a.marks1 > b.marks1 ||
                   (a.marks1 == b.marks1 && a.marks2 > b.marks2)) {

                    student1 temp = a;
                    list.set(j, b);
                    list.set(j + 1, temp);
                }
            }
        }

        for (student1 s : list) {
             System.out.println(s.marks1 + " " + s.marks2);
        }
    }
}

