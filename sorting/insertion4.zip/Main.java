/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;

class student1 {
    String name;
    int[] arr;

    student1(String name, int[] arr) {
        this.name = name;
        this.arr = arr;
    }
}

public class Main {
    public static void main(String[] args) {

        List<student1> list = new ArrayList<>();
        list.add(new student1("A", new int[]{1, 1, 3}));
        list.add(new student1("B", new int[]{1, 2, 3}));
        list.add(new student1("C", new int[]{2, 2, 1}));
        list.add(new student1("D", new int[]{1, 1, 2}));
        list.add(new student1("E", new int[]{1, 3, 0}));
        list.add(new student1("F", new int[]{0, 9, 9}));
        list.add(new student1("G", new int[]{2, 0, 0}));
        list.add(new student1("H", new int[]{1, 2, 2}));
        list.add(new student1("I", new int[]{1, 1, 1}));
        list.add(new student1("J", new int[]{3, 0, 0}));

        for (int i = 1; i < list.size(); i++) {
            student1 key = list.get(i);
            int j = i - 1;

            while (j >= 0) {
                student1 cur = list.get(j);
                boolean shift = false;

                for (int k = 0; k < cur.arr.length; k++) {
                    if (cur.arr[k] > key.arr[k]) {
                        shift = true;
                        break;
                    }
                    if (cur.arr[k] < key.arr[k]) {
                        break;
                    }
                }

                if (shift) {
                    list.set(j + 1, cur);
                    j--;
                } else {
                    break;
                }
            }
            list.set(j + 1, key);
        }

        for (student1 s : list) {
            System.out.println(s.name);
        }
    }
}

