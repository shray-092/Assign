/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
class  student{
    int marks1;
    int marks2;
    student(int marks1,int marks2){
        this.marks1=marks1;
        this.marks2=marks2;
        
    }
}

public class Main

{
	public static void main(String[] args) {

	    List<student>list=new ArrayList<>();
	    list.add(new student(13,24));
	    list.add(new student(23,45));
	    list.add(new student(13,244));
	    list.add(new student(21,67));
	    int i;
	    int j;
	    int mini;
	    for(i=0;i<list.size();i++){
	        
	        mini=i;
	        for(j=i+1;j<list.size();j++ ){
	            student left=list.get(j);
	            student right=list.get(mini);
	            if(left.marks1<right.marks1){
	                mini=j;
	                
	            }
	            if(left.marks1==right.marks1){
	                if(left.marks2<right.marks2){
	                    mini=j;
	                }
	            }
	        }
	        student temp=list.get(i);
	        list.set(i,list.get(mini));
	        list.set(mini,temp);
	        
	    }
	    for(student s: list){
	        System.out.print(s.marks1);
	        System.out.print(" ");
	        System.out.println(s.marks2);
	        
	    }
	    
	    
	    
		
	}
}
