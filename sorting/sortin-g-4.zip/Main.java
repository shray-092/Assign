/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;

class student1 {
    String name;
    int [] arr;
   

    student1(String name, int[] arr) {
        this.name = name;
        this.arr = arr;
    }


}

public class Main {
    public static void main(String[] args) {
        int k=0;

        List<student1> list = new ArrayList<>();
        list.add(new student1("A", new int[]{1, 1, 3}));
        list.add(new student1("B", new int[]{1, 2, 3}));
        list.add(new student1("C", new int[]{2, 2, 1}));
        list.add(new student1("D", new int[]{1, 1, 2}));
        list.add(new student1("E", new int[]{1, 3, 0}));
        list.add(new student1("F", new int[]{0, 9, 9}));
        list.add(new student1("G", new int[]{2, 0, 0}));
        list.add(new student1("H", new int[]{1, 2, 2}));
        list.add(new student1("I", new int[]{1, 1, 1}));
        list.add(new student1("J", new int[]{3, 0, 0}));
         
        for (int i = 0; i < list.size() - 1; i++) {
            for (int j = 0; j < list.size() - i - 1; j++) {
                student1 a=list.get(j);
                student1  b=list.get(j+1);
                for(k=0;k<b.arr.length;k++){
                    if(a.arr[k]>b.arr[k]){
                        student1 temp=a;
                        list.set(j,b);
                        list.set(j+1,temp);
                        break;
                    }
                    if(a.arr[k]<b.arr[k]){
                        break;
                    }
                }
                
                

            }
        }

        for (student1 s : list) {
             System.out.println(s.name);
        }
    }
}

