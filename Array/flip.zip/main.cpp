

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int r = sc.nextInt();
        int c = sc.nextInt();

        int[][] a = new int[r][c];

        for (int i = 0; i < r; i++) {
            for (int j = 0; j < c; j++) {
                a[i][j] = sc.nextInt();
            }
        }

        char choice = sc.next().charAt(0); 

        if (choice == 'v') {
          
            for (int i = 0; i < r; i++) {
                int left = 0, right = c - 1;
                while (left < right) {
                    int temp = a[i][left];
                    a[i][left] = a[i][right];
                    a[i][right] = temp;
                    left++;
                    right--;
                }
            }
        } else if (choice == 'h') {
           
            int top = 0, bottom = r - 1;
            while (top < bottom) {
                for (int j = 0; j < c; j++) {
                    int temp = a[top][j];
                    a[top][j] = a[bottom][j];
                    a[bottom][j] = temp;
                }
                top++;
                bottom--;
            }
        }

     
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < c; j++) {
                System.out.print(a[i][j] + " ");
            }
            System.out.println();
        }

        sc.close();
    }
}
