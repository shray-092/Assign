/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
public class Main
{
    
	public static void main(String[] args) {
	    int i;
	    int j;
	    Scanner sc=new Scanner(System.in);
	    int r=sc.nextInt();
	    int c=sc.nextInt();
	    int [][] y =new int[r][c];
	    for(i=0;i<r;i++){
	        for(j=0;j<c;j++){
	            int a=sc.nextInt();
	            y[i][j]=a;
	        }
	    }
	    int [][] transpose=new int[c][r];
	    for(i=0;i<c;i++){
	        for(j=0;j<r;j++){
	            
	            transpose[i][j]=y[j][i];
	        }
	    }
	     for(i=0;i<c;i++){
	        for(j=0;j<r;j++){
	            
	            System.out.println(transpose[i][j]);        }
	    }
	    
	    
	    
	    
	    
	}
}